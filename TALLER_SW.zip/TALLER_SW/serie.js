"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Serie = void 0;
class Serie {
    id;
    name;
    channel;
    seasons;
    description;
    webpage;
    poster;
    constructor(id, name, channel, seasons, description, webpage, poster) {
        this.id = id;
        this.name = name;
        this.channel = channel;
        this.seasons = seasons;
        this.description = description;
        this.webpage = webpage;
        this.poster = poster;
    }
}
exports.Serie = Serie;
//# sourceMappingURL=serie.js.map