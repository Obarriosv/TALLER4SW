import { series } from "./data.js";
import { Serie } from "./serie.js";
function renderSeriesInTable(series) {
    const tbody = document.getElementById("series-tbody");
    series.forEach((serie) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${serie.id}</td>
            <td>${serie.name}</td>
            <td>${serie.channel}</td>
            <td>${serie.seasons}</td>
        `;
        tbody.appendChild(row);
    });
}
renderSeriesInTable(series);
//# sourceMappingURL=main.js.map