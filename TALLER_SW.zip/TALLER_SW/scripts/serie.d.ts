declare class Serie {
    id: number;
    name: string;
    channel: string;
    seasons: number;
    description: string;
    webpage: string;
    poster: string;
    constructor(id: number, name: string, channel: string, seasons: number, description: string, webpage: string, poster: string);
}
export { Serie };
//# sourceMappingURL=serie.d.ts.map