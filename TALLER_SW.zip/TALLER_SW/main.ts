import { series } from "./data.js";
import { Serie } from "./serie.js";

console.log("CARGANDO...");
console.log(series);

function renderSeriesInTable(series: Serie[]): void {
    const tbody = document.getElementById("series-tbody")!;

    tbody.innerHTML = ""; // limpia

    series.forEach((serie) => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${serie.id}</td>
            <td>${serie.name}</td>
            <td>${serie.channel}</td>
            <td>${serie.seasons}</td>
        `;

        tbody.appendChild(row);
    });
}

renderSeriesInTable(series);